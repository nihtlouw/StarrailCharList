package com.dicoding.starrailcharlist.ui.theme

import androidx.compose.ui.graphics.Color

val GoldColor = Color(0xFFDAA520)
val GreyColor  = Color(0xFF808080)
val LightPurpleColor  = Color(0xFF9370DB)